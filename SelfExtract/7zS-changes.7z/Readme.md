# EdkRepo Installer 7-Zip Self Extracting Archive

## Overview

The EdkRepo installer utilizes 7-zip to create a self extracting archive. Which
enables the resulting installation binaries to be fully self-contained. Some
minor changes to self extracting archive program included with 7-Zip were
necessary to add support for installation inside of Windows containers.

## Changes Made

The self extracting .exe was changed from a Windows application to a console
application. It now checks the command line arguments for a "/silent" parameter.
If the /silent parameter is given, then all usage of GUI elements like dialogs
or message boxes is suppressed. Instead, the user is given error and progress
information by command line output only. If the /silent parameter is not given,
then the program immediately detaches from the console, and gives all error and
progress information via GUI elements as is done in the original implementation.

If the current session (called a "Window Station" in Win32 vernacular) does not
have an interactive desktop attached to it, then the /silent behavior will be
automatically activated, and the /silent parameter will be passed to the setup
program. The most common reason why an interactive desktop would not be
available is if a program is running in the context of a Windows service. A
relatively recent development is Windows containers. Windows containers also
run inside a Window Station that does not provide an interactive desktop. This
enables the detection of a Windows container environment and adjustment of
behavior to operates smoothly within it.

## Reproducing these changes

These changes are current based on 7-Zip 21.01. To reproduce this work:

1. Download
the source code for 7-Zip 21.01 from
[https://sourceforge.net/projects/sevenzip/files/7-Zip/22.01/7z2201-src.7z/download](https://sourceforge.net/projects/sevenzip/files/7-Zip/22.01/7z2201-src.7z/download).

2. Copy the files in the CHG directory into the extracted sources.

3. Open CPP\7zip\Bundles\SFXSetup\SFXSetup.dsw in Visual Studio 2008

4. Change the linker subsystem from WINDOWS to CONSOLE.

5. Build in Release mode.

6. The resulting file is placed in C:\UTIL\7zS.sfx

7. Modify this file with [Resource Hacker](http://www.angusj.com/resourcehacker/)
(or a similar program) and replace the application manifest with the application
manifest found in 7zS-original.sfx